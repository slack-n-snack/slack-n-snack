'use strict';

const dynamoose = require('dynamoose');

const orderSchema = new dynamoose.Schema({
  id: Number,
  clientId: String,
  orderPayload: Map,
  storeId: String,
  storeName: String,
});

const orderModel = dynamoose.model('slack-n-snack-table', orderSchema);

exports.handler = async (event) => {

  let { id, clientId, orderPayload, storeId, storeName } = JSON.parse(event.body);

  const order = { id, clientId, orderPayload, storeId, storeName };

  try {
    const postResponse = await orderModel.create(order);
    console.log('order payload:::::::::::::', postResponse);
  } catch (e) {
    console.log(e);
  } 
    
  console.log('event::::::::::::', event.body);
  // TODO implement
  const response = {
      statusCode: 200,
      body: JSON.stringify('Hello order added to database!'),
  };
  return response;
};